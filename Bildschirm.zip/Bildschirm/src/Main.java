import java.awt.*;
import java.awt.image.BufferStrategy;

public class Main {
    static Bildschirm derBildschirm;
    static Stift meinStift;
    public static void main(String[] args){
        derBildschirm = new Bildschirm(true, 800,800);
        meinStift = new Stift();

        System.out.println(Boolean.toString(derBildschirm.ZweifachPufferung));
        System.out.println(Integer.toString(derBildschirm.hoehe));
        System.out.println(Integer.toString(derBildschirm.breite));

        while (true){
            meinStift.render();
        }
    }
}
