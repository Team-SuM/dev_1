import jdk.jshell.spi.SPIResolutionException;

import java.awt.*;
import java.awt.image.BufferStrategy;

public class Stift {
    private BufferStrategy bs;
    private Graphics g;
    public Stift(){

    }
    public void init(){

    }

    public void refresh(){

    }

    public void render(){
        bs = Main.derBildschirm.getCanvas().getBufferStrategy();
        if (bs == null) {
            Main.derBildschirm.getCanvas().createBufferStrategy(3);
            return;
        }
        g = bs.getDrawGraphics();
        g.clearRect(0, 0, Main.derBildschirm.breite, Main.derBildschirm.hoehe);
        //START DRAWING
        g.drawString("hello world", 100 ,100);
        //END DRAWING
        bs.show();
        g.dispose();
    }
}
