import javax.swing.*;
import java.awt.*;
import java.awt.image.BufferStrategy;

public class Bildschirm {
    public int hoehe, breite;
    public String titel;
    public boolean ZweifachPufferung;
    JFrame frame;
    Canvas canvas;

    public Bildschirm(boolean ZweifachPufferung){
        init();
        this.ZweifachPufferung = ZweifachPufferung;
        create();
    }

    public Bildschirm(int breite, int hoehe){
        init();
        this.hoehe = hoehe;
        this.breite = breite;
        create();
    }

    public Bildschirm(boolean ZweifachPufferung, int breite, int hoehe){
        init();
        this.ZweifachPufferung = ZweifachPufferung;
        this.hoehe = hoehe;
        this.breite = breite;
        create();
    }

    private void create() {
        frame = new JFrame();
        canvas = new Canvas();
        frame.setPreferredSize(new Dimension(breite, hoehe));
        frame.setMaximumSize(new Dimension(breite, hoehe));
        frame.setMinimumSize(new Dimension(breite, hoehe));
        frame.setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        frame.setResizable(false);
        frame.setVisible(true);
        frame.add(canvas);
        canvas.setPreferredSize(new Dimension(breite, hoehe));
        canvas.setMaximumSize(new Dimension(breite, hoehe));
        canvas.setMinimumSize(new Dimension(breite, hoehe));

    }

    public void init(){
        ZweifachPufferung = false;
        breite = 800;
        hoehe = 800;
    }

    public void test(){

    }
    public Canvas getCanvas() {
        return this.canvas;
    }

    public JFrame getFrame() {
        return this.frame;
    }
}
